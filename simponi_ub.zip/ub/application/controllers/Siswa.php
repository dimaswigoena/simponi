<?php
class Siswa extends CI_Controller {

	/*
	 * Deskripsi Project :
	 * Nama File  : Controller Siswa
	 * Develop By : @DimasWigoena
	 * Author  By : @DimasWigoena
	 * Tanggal    :	
	 * Thanks To  : SMK Utama Bakti Palembang
	 * Versi      : V1.0
	 * STMIK GI MDP Palembang
	 */

	public function __construct(){
		parent::__construct();
		if($this->session->userdata('level')<>"3"){
			redirect('Login');
		}
	}

	public function index(){
		$dt['username'] = $this->session->userdata('username');
		$this->load->view('siswa/dashboard',$dt);
	}

	#Logout
	public function keluar(){
		$this->session->sess_destroy($dt);
		redirect ('login');
	}

	#Menampilkan Data Siswa
	public function datasiswa($nis){
		$this->load->model('M_siswa');
		$data_siswa['list_siswa'] = $this->M_siswa->ambil_tb_siswa($nis);
		$this->load->view('siswa/lihat_data_siswa',$data_siswa);
	}

	#Kata Sandi
	public function ubah_katasandi($username){
		$this->load->model('M_siswa');
		$data_login['user'] = $this->M_siswa->ambil_tb_login($username);
		$this->load->view('siswa/ubah_katasandi', $data_login);
	}

	public function ganti_sandi($username){
		$this->load->model('M_siswa');
		$data['user'] = $this->M_siswa->ambil_tb_login($username);
		
		if(isset($data['user']['username'])){
        	$password1 = md5($this->input->post('password1'));
        	$password2 = md5($this->input->post('password2'));
			$this->form_validation->set_rules('password1','Password Baru','required');
			
			if ($password1 != $password2){
				$this->session->set_flashdata('notif','Password Tidak Sama, Silahkan Ulangi !');
				$this->load->view('siswa/ubah_katasandi',$data);
			}elseif ($this->form_validation->run()) {
				$data_baru = array(
					'username' => $username,
					'katasandi' => md5($this->input->post("password2"))
					);
				$this->M_siswa->update_tb_login($username,$data_baru);
				$this->load->model('M_siswa');
				$data_siswa['list_siswa'] = $this->M_siswa->ambil_tb_siswa($username);
                $this->session->set_flashdata('notif',' Kata Sandi Berhasil Di Ubah !');           
                $this->load->view('siswa/lihat_data_siswa',$data_siswa);
			}else{   
                $this->load->view('siswa/lihat_data_siswa',$data);
            }
        }else{
            $this->load->view('siswa/lihat_data_siswa',$data);
        }
	}

	#Menampilkan Jadwal
	public function lihatjadwal($nis){
		$this->load->model('M_siswa');
		$data['list_jadwal'] = $this->M_siswa->ambiljadwal($nis);
		$this->load->view('siswa/lihat_data_jadwal',$data);
	}

	#Menampilkan Jadwal
	public function lihatjadwal2($nis){
		$this->load->model('M_siswa');
		$data['list_jadwal'] = $this->M_siswa->ambiljadwal2($nis);
		$this->load->view('siswa/data_materi',$data);
	}

	#Menampilkan Materi
	public function lihatmateri($kd_mapel, $kd_kelas){
		$this->load->model('M_siswa');
		$data['list_materi'] = $this->M_siswa->ambilmateri($kd_mapel,$kd_kelas);
		$this->load->view('siswa/list_materi',$data);
	}

	public function download_materi($id){
		$this->load->model('M_siswa');
        $ambil = $this->M_siswa->ambilmateri2($id);
        $path = 'data/materi/'.$ambil['file'];
        force_download($path, NULL);
	}

	public function lihatnilai($nis){
		$this->load->model('M_siswa');
		$data_siswa['list_siswa'] = $this->M_siswa->ambil_tb_siswa($nis);
		$this->load->view('siswa/data_nilai',$data_siswa);
	}

	public function cari_nilai($nis, $kode_kelas){
		$this->load->model('M_siswa');
		$kode_kelas = $this->input->post('kelas');
		$data_nilai['list_nilai'] = $this->M_siswa->ambil_tb_nilai($kode_kelas, $nis);
		$this->load->view('siswa/list_nilai',$data_nilai);
	}
}
