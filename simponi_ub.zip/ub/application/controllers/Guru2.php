<?php
class Guru2 extends CI_Controller {

	/*
	 * Deskripsi Project :
	 * Nama File  : Controller Guru2
	 * Develop By : @DimasWigoena
	 * Author  By : @DimasWigoena
	 * Tanggal    :
	 * Thanks To  : SMK Utama Bakti Palembang
	 * Versi      : V1.0
	 * STMIK GI MDP Palembang
	 */

	/*************
	 * Data Guru *
	 *************/

	#Menampilkan Data Guru
	public function lihat_data_guru($kode){
		$this->load->model('Crud_guru');
		$ambil['data_guru'] = $this->Crud_guru->ambil_tb_guru($kode);
		$this->load->view('admin/lihat_data_guru',$ambil);
	}

	#Menampilkan Form Input
	public function input_data_guru(){
		$this->load->view('admin/input_data_guru', array('error' => ' ' ));
	}

	#Menambahkan data guru
	public function add(){

		$this->load->model("Crud_guru");

		$kode_guru		= $this->input->POST('kode_guru');
		$nama_guru		= $this->input->POST('nama_guru');
		$jenis_kelamin	= $this->input->POST('jenis_kelamin');
		$status			= $this->input->POST('status');
		$matapelajaran	= $this->input->POST('matapelajaran');
		$tempat_lahir	= $this->input->POST('tempat_lahir');
		$tgl_lahir		= $this->input->POST('tgl_lahir');
		$alamat			= $this->input->POST('alamat');
		$telp 			= $this->input->POST('telp');
		$tmt 			= $this->input->POST('tmt');
		$username		= $this->input->POST('kode_guru');
		$katasandi		= md5($this->input->POST('katasandi'));

		$this->form_validation->set_rules('kode_guru','Kode Guru','required|numeric');
		$this->form_validation->set_rules('nama_guru','Nama Guru','required');
		$this->form_validation->set_rules('jenis_kelamin','Jenis Kelamin','required');
		$this->form_validation->set_rules('status','Status','required');
		$this->form_validation->set_rules('matapelajaran','Matapelajaran','callback_mapel_check');
		$this->form_validation->set_rules('tempat_lahir','Tempat Lahir','required');
		$this->form_validation->set_rules('tgl_lahir','Tanggal Lahir','required');
		$this->form_validation->set_rules('alamat','Alamat','required');
		$this->form_validation->set_rules('telp','No Telepon','required|numeric');
		$this->form_validation->set_rules('tmt','Terhitung Mulai Tugas','required|numeric|min_length[4]');
		$this->form_validation->set_rules('katasandi','Katasandi','required|min_length[6]');

		#Upload Gambar
		$config['upload_path']    = 'data/foto/guru';
        $config['allowed_types']  = 'jpg|png';
        $config['max_size']       = 2048;
        $config['max_width']      = 2048;
        $config['max_height']     = 2048;

        $this->upload->initialize($config);
        $this->load->library('upload', $config);

        if (($this->form_validation->run()==FALSE) && (!$this->upload->do_upload('foto'))){
			$error = array('error' => $this->upload->display_errors());
    		$this->load->view('admin/input_data_guru',$error);
        }elseif ($this->form_validation->run()==FALSE) {
        	$error = array('error' => $this->upload->display_errors());
    		$this->load->view('admin/input_data_guru',$error);
        }
        elseif (!$this->upload->do_upload('foto')){
        	$error = array('error' => $this->upload->display_errors());
    		$this->load->view('admin/input_data_guru',$error);
        }else{	        	
        	$upload = $this->upload->data();    	
        	$data = array(
        		'nama_file'   => $upload['file_name']
        	);

	        $dataguru = array(
	        	'kode_guru'		=> $kode_guru,
	        	'nama_guru'		=> $nama_guru,
	        	'kode_mapel'	=> $matapelajaran,
	        	'status'		=> $status,
	        );

	        $datadetail = array(
	        	'kode_guru'		=> $kode_guru,
	        	'jenis_kelamin'	=> $jenis_kelamin,
	        	'alamat'		=> $alamat,
	        	'tempat_lahir'	=> $tempat_lahir,
	        	'tanggal_lahir'	=> $tgl_lahir,
	        	'no_tlp'		=> $telp,
	        	'tmt'			=> $tmt,
	        	'foto'			=> $data['nama_file']
	        );

	        $datalogin = array(
	        	'username'		=> $username,
	        	'katasandi'		=> $katasandi,
	        	'level'			=> 2
	        );

	        $this->Crud_guru->add_data('tb_guru', $dataguru);
			$this->Crud_guru->add_data('tb_detailguru', $datadetail);
			$this->Crud_guru->add_data('tb_login', $datalogin);
			$this->session->set_flashdata('notif',' Data Berhasil Disimpan !');
			redirect('admin/tampil_data_guru');	
		}
	}

	#Menampilkan Form Edit
	public function edit_data_guru($kd_guru){
		$this->load->model('Crud_guru');
		$ambil['data_guru'] = $this->Crud_guru->ambil_tb_guru($kd_guru);
		$this->load->view('admin/edit_data_guru',$ambil);
	}

	#Edit Data Guru
	public function update($kd_guru){
		$this->load->model("Crud_guru");

		$kode_guru		= $this->input->POST('kode_guru');
		$nama_guru		= $this->input->POST('nama_guru');
		$jenis_kelamin	= $this->input->POST('jenis_kelamin');
		$status			= $this->input->POST('status');
		$matapelajaran	= $this->input->POST('matapelajaran');
		$tempat_lahir	= $this->input->POST('tempat_lahir');
		$tgl_lahir		= $this->input->POST('tanggal_lahir');
		$alamat			= $this->input->POST('alamat');
		$telp 			= $this->input->POST('telp');
		$tmt 			= $this->input->POST('tmt');
		$username		= $this->input->POST('kode_guru');
		$foto_lama		= $this->input->POST('foto_lama');

		$this->form_validation->set_rules('kode_guru','Kode Guru','required');
		$this->form_validation->set_rules('nama_guru','Nama Guru','required');
		$this->form_validation->set_rules('jenis_kelamin','Jenis Kelamin','required');
		$this->form_validation->set_rules('status','Status','required');
		$this->form_validation->set_rules('matapelajaran','Matapelajaran','callback_mapel_check');
		$this->form_validation->set_rules('tempat_lahir','Tempat Lahir','required');
		$this->form_validation->set_rules('tanggal_lahir','Tanggal Lahir','required');
		$this->form_validation->set_rules('alamat','Alamat','required');
		$this->form_validation->set_rules('telp','No Telepon','required|numeric');
		$this->form_validation->set_rules('tmt','Terhitung Mulai Tugas','required|min_length[4]|numeric');

		#Proses Upload Gambar
			$config['upload_path']    = 'data/foto/guru';
		    $config['allowed_types']  = 'jpg|png';
		    $config['max_size']       = 2048;
		    $config['max_width']      = 2048;
		    $config['max_height']     = 2048;

		    $this->upload->initialize($config);
		    $this->load->library('upload', $config);

    	if ((!$this->upload->do_upload('foto_baru'))){
			$error = array('error' => $this->upload->display_errors());
		}else{
			$ambil = $this->Crud_guru->ambil_tb_guru($kd_guru);
			$path = 'data/foto/guru/'.$ambil['foto'];
			unlink($path);          	
    		$upload = $this->upload->data();    	
        	$foto_lama = $upload['file_name'];
		}

	        $dataguru = array(
	        	'kode_guru'		=> $kode_guru,
	        	'nama_guru'		=> $nama_guru,
	        	'kode_mapel'	=> $matapelajaran,
	        	'status'		=> $status,
	        );

	        $datadetail = array(
	        	'kode_guru'		=> $kode_guru,
	        	'jenis_kelamin'	=> $jenis_kelamin,
	        	'alamat'		=> $alamat,
	        	'tempat_lahir'	=> $tempat_lahir,
	        	'tanggal_lahir'	=> $tgl_lahir,
	        	'no_tlp'		=> $telp,
	        	'tmt'			=> $tmt,
	        	'foto'			=> $foto_lama
	        );

	        $datalogin = array(
	        	'username'		=> $username
	        );

	        $this->Crud_guru->update_guru($kd_guru, $dataguru);
			$this->Crud_guru->update_detailguru($kd_guru, $datadetail);
			$this->Crud_guru->update_login($kd_guru, $datalogin);
			$this->session->set_flashdata('notif',' Data Berhasil Diubah !');
			$ambil['data_guru'] = $this->Crud_guru->ambil_tb_guru($kd_guru);
			$this->load->view('admin/edit_data_guru',$ambil);
	}

	#Kata Sandi
	public function ubah_katasandi($username){
		$this->load->model('Crud_guru');
		$data['user'] = $this->Crud_guru->ambil_tb_login($username);
		$this->load->view('admin/ubah_katasandi_guru',$data);
	}

	public function ganti_sandi($username){
		$this->load->model('Crud_guru');
		$data['user'] = $this->Crud_guru->ambil_tb_login($username);
		if(isset($data['user']['username'])){
        	$password1 = md5($this->input->post('password1'));
        	$password2 = md5($this->input->post('password2'));
			$this->form_validation->set_rules('password1','Password Baru','required|min_length[6]');
			
			if ($password1 != $password2) {
				$this->session->set_flashdata('notif','Password Tidak Sama, Silahkan Ulangi !');
				$this->load->view('admin/ubah_katasandi_guru',$data);
			}elseif ($this->form_validation->run()) {
				$data_baru = array(
					'username' => $username,
					'katasandi' => md5($this->input->post("password2"))
				);
				$this->Crud_guru->update_login($username,$data_baru);
                $this->session->set_flashdata('notif',' Kata Sandi Berhasil Di Ubah !');          
                redirect('admin/tampil_data_guru');
			}else{   
                $this->load->view('admin/ubah_katasandi_guru',$data);
            }
        }else{
            $this->load->view('admin/tampil_data_guru',$data);
        }
	}

	#Cari Data
	public function cari(){
		$this->load->model('Crud_guru');
		$cari = $this->input->POST('cari');		
		$data['cari'] = $this->Crud_guru->cari($cari);
		$this->load->view('admin/cari_guru',$data);
	}

	#Cek Combobox Matapelajaran
	public function mapel_check($mapel){
		if ($mapel == 'none'){
			$this->form_validation->set_message('mapel_check','Silahkan Pilih Matapelajaran');
			return FALSE;
		}else{
			return TRUE;
		}
	}
}