<?php
class Jadwal extends CI_Controller {

	/*
	 * Deskripsi Project :
	 * Nama File  : Controller Jadwal
	 * Develop By : @DimasWigoena
	 * Author  By : @DimasWigoena
	 * Tanggal    :
	 * Thanks To  : SMK Utama Bakti Palembang
	 * Versi      : V1.0
	 * STMIK GI MDP Palembang
	 */

	#Data Jadwal
	public function lihat_data_jadwal($kode_kelas){
		$this->load->model('Crud_jadwal');
		$data['list_jadwal'] = $this->Crud_jadwal->ambil_jadwal($kode_kelas);	
		$this->load->view('admin/lihat_data_jadwal',$data);
	}

	#Input Data Jadwal
	public function input_data_jadwal(){
		$this->load->model('Crud_jadwal');

		$kelas 			= $this->input->post('kelas');
		$hari 			= $this->input->post('hari');
		$mapel 			= $this->input->post('matapelajaran');
		$guru 			= $this->input->post('guru_pengajar');
		$jamke			= $this->input->post('jamke');
		$jam_mulai 		= $this->input->post('jam_mulai');
		$jam_selesai 	= $this->input->post('jam_selesai');
		$ruangan 		= $this->input->post('ruangan');

		$this->form_validation->set_rules('hari','Hari','callback_hari_check');
		$this->form_validation->set_rules('matapelajaran','Matapelajaran','callback_mapel_check');
		$this->form_validation->set_rules('guru_pengajar','Guru','callback_guru_check');
		$this->form_validation->set_rules('jam_mulai','Jama Mulai','required');
		$this->form_validation->set_rules('jam_selesai','Jam Selesai','required');
		$this->form_validation->set_rules('ruangan','Ruangan','callback_ruangan_check');
		$this->form_validation->set_rules('jamke','Jamke','callback_jamke_check');

		if ($this->form_validation->run()==FALSE) {
			$data['list_kelas'] = $this->Crud_jadwal->ambil_kelas($kelas);
			$data['list_jadwal'] = $this->Crud_jadwal->ambil_jadwal($kelas);
			$this->load->view('admin/edit_data_jadwal',$data);
		}else{
			$datajadwal = array(
				'kode_kelas' 	=> $kelas,
				'kode_mapel' 	=> $mapel,
				'kode_guru'  	=> $guru,
				'kode_ruangan'	=> $ruangan,
				'kode_hari'	 	=> $hari,
				'jamke'			=> $jamke,
				'jam'	 	 	=> $jam_mulai." - ".$jam_selesai
			);
			$this->Crud_jadwal->add_jadwal($datajadwal);
			$this->session->set_flashdata('notif',' Data Berhasil Disimpan !');
			$data['list_kelas'] = $this->Crud_jadwal->ambil_kelas($kelas);
			$this->load->view('admin/edit_data_jadwal',$data);
		}
	}

	#Edit Data Jadwal
	public function edit_jadwal($kelas){
		$this->load->model('Crud_jadwal');
		$data['list_kelas'] = $this->Crud_jadwal->ambil_kelas($kelas);
		$this->load->view('admin/edit_data_jadwal', $data);
	}

	#Hapus Data Jadwal
	public function delete_jadwal($id){
		$this->load->model('Crud_jadwal');
		$ambil = $this->Crud_jadwal->ambil_all_jadwal($id);
		if(isset($ambil['id'])){
            $this->Crud_jadwal->delete_jadwal($id);
            $this->session->set_flashdata('notif',' Data Berhasil Di Hapus !');
            redirect('admin/tampil_data_jadwal');
        }
	}

	#Cek Combobox Hari
	public function hari_check($jur){
		if ($jur == 'none'){
			$this->form_validation->set_message('hari_check','Silahkan Pilih Hari');
			return FALSE;
		}else{
			return TRUE;
		}
	}

	#Cek Combobox Data Jurusan
	public function mapel_check($jur){
		if ($jur == 'none'){
			$this->form_validation->set_message('mapel_check','Silahkan Pilih Matapelajaran');
			return FALSE;
		}else{
			return TRUE;
		}
	}

	#Cek Combobox Data Jurusan
	public function guru_check($jur){
		if ($jur == 'none'){
			$this->form_validation->set_message('guru_check','Silahkan Pilih Guru');
			return FALSE;
		}else{
			return TRUE;
		}
	}

	#Cek Combobox Data Jurusan
	public function ruangan_check($jur){
		if ($jur == 'none'){
			$this->form_validation->set_message('ruangan_check','Silahkan Pilih Ruang');
			return FALSE;
		}else{
			return TRUE;
		}
	}

	#Cek Combobox Data Jurusan
	public function jamke_check($jur){
		if ($jur == 'none'){
			$this->form_validation->set_message('jamke_check','Silahkan Pilih Jam');
			return FALSE;
		}else{
			return TRUE;
		}
	}
}