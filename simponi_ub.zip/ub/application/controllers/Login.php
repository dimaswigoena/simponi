<?php
class Login extends CI_Controller {

	/*
	 * Deskripsi Project :
	 * Nama File  : Controller Login
	 * Develop By : @DimasWigoena
	 * Author  By : @DimasWigoena
	 * Tanggal    :
	 * Thanks To  : SMK Utama Bakti Palembang
	 * Versi      : V1.0
	 * STMIK GI MDP Palembang
	 */

	public function index(){
		$this->load->view('halaman_login');
	}

	#Cek Status Login
	public function masuk(){
		$username 	= $this->input->POST('username');
		$katasandi	= md5($this->input->POST('password'));
		
		$this->form_validation->set_rules('username','Username','required');
		$this->form_validation->set_rules('password','Password','required');

		if($this->form_validation->run()){
			$this->load->model('validasi');
			$hasil = $this->validasi->cek_login($username, $katasandi);

			if($hasil->num_rows() == 1){
				foreach ($hasil->result() as $data){
					$sess_data['logged_in'] 	= 'Sudah Login';
					$sess_data['no']			= $data->id_login;
					$sess_data['username']		= $data->username;
					$sess_data['level']			= $data->level;
					$this->session->set_userdata($sess_data);	
				}

				if ($this->session->userdata('level') == '1'){
					redirect(admin);
				}elseif ($this->session->userdata('level') == '2'){
					redirect(guru);
				}elseif ($this->session->userdata('level') == '3'){
					redirect(siswa);
				} 
			}else{
				$this->session->set_flashdata('notif',' Maaf ! NIS/Kode atau Password Salah !');
				redirect('login');
			}
		}else{
			$this->session->set_flashdata('notif',' NIS/Kode dan Password Harus Diisi !');
			redirect('login');
		}		
	}
}

