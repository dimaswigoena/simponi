<?php
class Mapel extends CI_Controller {

	/**
	 * Deskripsi Project :
	 * Nama File  : Controller Matapelajaran
	 * Develop By : @DimasWigoena
	 * Author  By : @DimasWigoena
	 * Tanggal    :
	 * Thanks To  : SMK Utama Bakti Palembang
	 * Versi      : V1.0
	 * STMIK GI MDP Palembang
	 */		

	/***********************
	 * Data Mata Pelajaran *
	 ***********************/

	#Menampilkan Form Input Data Metapelajaran
	public function input_data_mapel(){
		$this->load->view('admin/input_data_mapel');
	}

	#Menyimpan Data Matapelajaran
	public function add(){
		$this->load->model('Crud_mapel');
		$kode_mapel = $this->input->POST('kd_mapel');
		$nama_mapel = $this->input->POST('nama_mapel');

		$this->form_validation->set_rules('kd_mapel','Kode Matapelajaran','required');
		$this->form_validation->set_rules('nama_mapel','Nama Matapelajaran','required');

		if($this->form_validation->run()){ 
			$datainput_mapel = array(
				'kode_mapel' => $kode_mapel,
				'nama_mapel' => $nama_mapel
			);

			$this->Crud_mapel->add_mapel($datainput_mapel);
			$this->session->set_flashdata('notif',' Data Berhasil Disimpan !');
			redirect('admin/tampil_data_mapel');
		}else{
            $this->load->view('admin/input_data_mapel');
        }
	}

	#Hapus Data Matapelajaran
    public function remove($kode_mapel){
    	$this->load->model('Crud_mapel');
        $ambil = $this->Crud_mapel->ambil_tb_matapelajaran($kode_mapel);

        if(isset($ambil['kode_mapel'])){
            $hapus = $this->Crud_mapel->delete_mapel($kode_mapel);
            if ($hapus == FALSE) {
            	$this->session->set_flashdata('notif',' Data Gagal Di Hapus !');
            	redirect('admin/tampil_data_mapel');	
            }else{
            	$this->session->set_flashdata('notif',' Data Berhasil Di Hapus !');
            	redirect('admin/tampil_data_mapel');
            }
            
        }
    }	

    #Edit Data Matapelajaran
    function edit($kode_mapel){   
    	$this->load->model('Crud_mapel');
        $data['matapelajaran'] = $this->Crud_mapel->ambil_tb_matapelajaran($kode_mapel);
        
        if(isset($data['matapelajaran']['kode_mapel'])){
            $this->load->library('form_validation');
			$this->form_validation->set_rules('nama_mapel','Nama Mapel','required');
		
			if($this->form_validation->run()){   
                $data_mapel = array(
                	'kode_mapel' => $this->input->post('kd_mapel'),
					'nama_mapel' => $this->input->post('nama_mapel')
                );

                $this->Crud_mapel->update_tb_matapelajaran($kode_mapel,$data_mapel);
                $this->session->set_flashdata('notif',' Data Berhasil Di Ubah !');             
                redirect('admin/tampil_data_mapel');
            }else{
                $this->load->view('admin/edit_data_mapel',$data);
            }
        }
    }
}
