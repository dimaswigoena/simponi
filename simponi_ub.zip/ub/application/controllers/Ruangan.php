<?php
class Ruangan extends CI_Controller {

	/**
	 * Deskripsi Project :
	 * Nama File  : Controller Ruangan
	 * Develop By : @DimasWigoena
	 * Author  By : @DimasWigoena
	 * Tanggal    :
	 * Thanks To  : SMK Utama Bakti Palembang
	 * Versi      : V1.0
	 * STMIK GI MDP Palembang
	 */

	/******************
	 * Data Ruangan *
	 ******************/

	#Menampilkan Form Input Data Ruangan
	public function input_data_ruangan(){
		$this->load->view('admin/input_data_ruangan');
	}

	#Menyimpan Data Ruangan
	public function add(){
		$this->load->model('Crud_ruangan');
		$kode_ruangan = $this->input->POST('kd_ruangan');
		$nama_ruangan = $this->input->POST('nama_ruangan');

		$this->form_validation->set_rules('kd_ruangan','Kode ruangan','required');
		$this->form_validation->set_rules('nama_ruangan','Nama ruangan','required');

		if ($this->form_validation->run()){
			$datainput_ruangan = array(
				'kode_ruangan' => $kode_ruangan,
				'nama_ruangan' => $nama_ruangan
			);
			$this->Crud_ruangan->add_ruangan($datainput_ruangan);
			$this->session->set_flashdata('notif',' Data Berhasil Disimpan !');
			redirect('admin/tampil_data_ruangan');
		}else{
			$this->load->view('admin/input_data_ruangan');
		}
	}

	#Menghapus Data Ruangan
    public function remove($kode_ruangan){
    	$this->load->model('Crud_ruangan');
        $ambil = $this->Crud_ruangan->ambil_tb_ruangan($kode_ruangan);

        if(isset($ambil['kode_ruangan'])){
			$hapus = $this->Crud_ruangan->delete_ruangan($kode_ruangan);
			if ($hapus == FALSE) {
				$this->session->set_flashdata('notif',' Data Gagal Di Hapus !');
				redirect('admin/tampil_data_ruangan');
			}else{
				$this->session->set_flashdata('notif',' Data Berhasil Di Hapus !');
				redirect('admin/tampil_data_ruangan');
			}
        }
    }

	#Merubah Data Ruangan
    function edit($kode_ruangan){
    	$this->load->model('Crud_ruangan');
        $data['ruangan'] = $this->Crud_ruangan->ambil_tb_ruangan($kode_ruangan);

        if(isset($data['ruangan']['kode_ruangan'])){
            $this->load->library('form_validation');
			$this->form_validation->set_rules('nama_ruangan','Nama ruangan','required');

			if($this->form_validation->run()){
                $data_ruangan = array(
                    'kode_ruangan' => $this->input->post('kd_ruangan'),
					'nama_ruangan' => $this->input->post('nama_ruangan')
                );
                $this->Crud_ruangan->update_ruangan($kode_ruangan,$data_ruangan);
                $this->session->set_flashdata('notif',' Data Berhasil Di Ubah !');
                redirect('admin/tampil_data_ruangan');
            }else{
                $this->load->view('admin/edit_data_ruangan',$data);
            }
        }
    }
}
