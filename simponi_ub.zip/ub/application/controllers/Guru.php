<?php
class Guru extends CI_Controller {

	/*
	 * Deskripsi Project :
	 * Nama File  : Controller Guru
	 * Develop By : @DimasWigoena
	 * Author  By : @DimasWigoena
	 * Tanggal    :
	 * Thanks To  : SMK Utama Bakti Palembang
	 * Versi      : V1.0
	 * STMIK GI MDP Palembang
	 */

	public function __construct(){
		parent::__construct();
		if($this->session->userdata('level')<>"2"){
			redirect('Login');
		}
	}

	public function index(){
		$dt['username'] = $this->session->userdata('username');
		$this->load->view('guru/dashboard',$dt);
	}

	#Logout
	public function keluar(){
		$this->session->sess_destroy($dt);
		redirect ('login');
	}

	#Data Guru
	public function dataguru($kode_guru){
		$this->load->model('M_guru');
		$data['list_guru'] = $this->M_guru->ambil_tb_guru($kode_guru);
		$this->load->view('guru/lihat_data_guru',$data);
	}

	#Data Jadwal
	public function lihatjadwal($kode_guru){
		$this->load->model('M_guru');
		$data['list_jadwal'] = $this->M_guru->ambiljadwal($kode_guru);
		$this->load->view('guru/lihat_data_jadwal',$data);
	}

	#Data Jadwal
	public function lihatjadwal2($kode_guru){
		$this->load->model('M_guru');
		$data['list_jadwal'] = $this->M_guru->ambiljadwal2($kode_guru);
		$this->load->view('guru/data_materi_kelas',$data);
	}

	#Kata Sandi
	public function ubah_katasandi($username){
		$this->load->model('M_guru');
		$data_login['user'] = $this->M_guru->ambil_tb_login($username);
		$this->load->view('guru/ubah_katasandi',$data_login);
	}

	public function ganti_sandi($username){
		$this->load->model('M_guru');
		$data['user'] = $this->M_guru->ambil_tb_login($username);
		if(isset($data['user']['username'])){
        	$password1 = md5($this->input->post('password1'));
        	$password2 = md5($this->input->post('password2'));
			$this->form_validation->set_rules('password1','Password Baru','required');
			
			if ($password1 != $password2){
				$this->session->set_flashdata('notif','Password Tidak Sama, Silahkan Ulangi !');
				$this->load->view('guru/ubah_katasandi',$data);
			}else if ($this->form_validation->run()) {
				$data_baru = array(
					'username' => $username,
					'katasandi' => md5($this->input->post("password2"))
				);
				$this->M_guru->update_tb_login($username,$data_baru);
				$this->load->model('M_guru');
				$data['list_guru'] = $this->M_guru->ambil_tb_guru($username);
                $this->session->set_flashdata('notif',' Kata Sandi Berhasil Di Ubah !');           
                $this->load->view('guru/lihat_data_guru',$data);
			}else{   
                $this->load->view('guru/ubah_katasandi',$data);
            }
        }else{
            $this->load->view('guru/lihat_data_guru',$data);
        }
	}

	#Data Materi
	public function materi($kode_mapel, $kode_kelas){
		$this->load->model('M_guru');
		$data['list_materi'] = $this->M_guru->ambilmateri($kode_mapel, $kode_kelas);
		$this->load->view('guru/list_materi', $data);
	}

	public function input_materi($kode_mapel, $kode_kelas){
		$this->load->model('M_guru');
		$data['materi'] = $this->M_guru->ambilmateri1($kode_mapel, $kode_kelas);
		$this->load->view('guru/input_materi_kelas', $data);
	}

	public function add_materi(){
		$this->load->model('M_guru');

		$pertemuan		= $this->input->post('pertemuan');
		$judul_materi	= $this->input->post('judul_materi');
		$tanggal_input	= $this->input->post('tgl_input');
		$kode_mapel 	= $this->input->post('kode_mapel');
		$kode_kelas		= $this->input->post('kode_kelas');

		$this->form_validation->set_rules('pertemuan','Pertemuan','required|numeric');
		$this->form_validation->set_rules('judul_materi','Judul','required');
		$this->form_validation->set_rules('tanggal_input','Tanggal','required');

		#Upload File Materi
		$config['upload_path']    = 'data/materi';
        $config['allowed_types']  = '*';
        $config['max_size']       = 20480;

        $this->upload->initialize($config);
        $this->load->library('upload', $config);

		if (($this->form_validation->run()==FALSE) && (!$this->upload->do_upload('file'))) {
			$data['materi'] = $this->M_guru->ambilmateri1($kode_mapel, $kode_kelas);
			$error = array('error' => $this->upload->display_errors());
			$this->load->view('guru/input_materi_kelas',$data);
		}else{
			$upload = $this->upload->data();    	
        	$data = array(
        		'nama_file'   => $upload['file_name']
        	);
        	$datamateri = array(
        		'kode_mapel' 	=> $kode_mapel,
        		'kode_kelas' 	=> $kode_kelas,
        		'judul_materi'	=> $judul_materi,
        		'file'			=> $data['nama_file'],
        		'tanggal_input'	=> $tanggal_input,
        		'pertemuan_ke'	=> $pertemuan
        	);
        	$this->M_guru->add_materi($datamateri);
        	$this->session->set_flashdata('notif',' Data Berhasil Disimpan !');
        	$data['materi'] = $this->M_guru->ambilmateri1($kode_mapel, $kode_kelas);
			$this->load->view('guru/input_materi_kelas', $data);
		}
	}

	public function edit_materi($id){
		$this->load->model('M_guru');
		$data['list_materi'] = $this->M_guru->ambilmateri2($id);
		$this->load->view('guru/edit_materi_kelas',$data);
	}

	public function ubah_materi($id){
		$this->load->model('M_guru');

		$pertemuan		= $this->input->post('pertemuan');
		$judul_materi	= $this->input->post('judul_materi');
		$tanggal_input	= $this->input->post('tgl_input');
		$kode_mapel 	= $this->input->post('kode_mapel');
		$kode_kelas		= $this->input->post('kode_kelas');
		$file_lama		= $this->input->post('file_lama');

		$this->form_validation->set_rules('pertemuan','Pertemuan','required|numeric');
		$this->form_validation->set_rules('judul_materi','Judul','required');
		$this->form_validation->set_rules('tanggal_input','Tanggal','required');

		#Upload File Materi
		$config['upload_path']    = 'data/materi';
        $config['allowed_types']  = '*';
        $config['max_size']       = 20480;

        $this->upload->initialize($config);
        $this->load->library('upload', $config);

        if ((!$this->upload->do_upload('file_baru'))){
    		$error = array('error' => $this->upload->display_errors());
    	}else{          	
        	$upload = $this->upload->data();    	
	       	$file_lama = $upload['file_name'];
		}

		$datamateri = array(
    		'kode_mapel' 	=> $kode_mapel,
    		'kode_kelas' 	=> $kode_kelas,
    		'judul_materi'	=> $judul_materi,
    		'file'			=> $file_lama,
    		'tanggal_input'	=> $tanggal_input,
    		'pertemuan_ke'	=> $pertemuan
    	);
    	$this->M_guru->edit_materi($datamateri, $id);
    	$this->session->set_flashdata('notif',' Data Berhasil Diubah !');
    	$data['list_materi'] = $this->M_guru->ambilmateri($kode_mapel, $kode_kelas);
		$this->load->view('guru/list_materi', $data);
	}

	public function hapus_materi($id){
		$this->load->model('M_guru');
        $ambil = $this->M_guru->ambilmateri2($id);
        $path = 'data/materi/'.$ambil['file'];
        $kode_mapel = $ambil['kode_mapel'];
        $kode_kelas = $ambil['kode_kelas'];

        if(isset($ambil['id'])){
        	unlink($path);
            $this->M_guru->delete_materi($id);
            $this->session->set_flashdata('notif',' Data Berhasil Dihapus !');
    		$data['list_materi'] = $this->M_guru->ambilmateri($kode_mapel, $kode_kelas);
			$this->load->view('guru/list_materi', $data);  
        }
	}

	public function download_materi($id){
		$this->load->model('M_guru');
        $ambil = $this->M_guru->ambilmateri2($id);
        $path = 'data/materi/'.$ambil['file'];
        force_download($path, NULL);
	}

	#Data Nilai
	public function list_nilai($kode_guru){
		$this->load->model('M_guru');
		$data['list_jadwal'] = $this->M_guru->ambiljadwal2($kode_guru);
		$this->load->view('guru/input_nilai_siswa',$data);
	}

	public function input_nilai($kode_mapel, $kode_kelas){
		$this->load->model('M_guru');
		$data['list_siswa'] = $this->M_guru->ambil_nilai($kode_mapel,$kode_kelas);
		$this->load->view('guru/list_nilai',$data);
	}

	public function add_nilai($kode_mapel, $kode_kelas){
		$this->load->model('M_guru');
		$data['list_siswa'] = $this->M_guru->ambil_siswa($kode_mapel,$kode_kelas);
		$this->load->view('guru/input_nilai',$data);
	}

	public function add_nilai2($kode_mapel, $kode_kelas){
		$this->load->model('M_guru');
		
		$datasiswa = array(
			'nis' 				=> $this->input->post('nama_siswa'),
			'kode_mapel'		=> $this->input->post('kode_mapel'),
			'kode_kelas' 		=> $this->input->post('kode_kelas'),
			'nilai_ulangan'		=> 0,
			'nilai_tugas'		=> 0,
			'nilai_mid'			=> 0,
			'nilai_semester1'	=> 0,
			'nilai_semester2'	=> 0,
			'nilai_akhir'		=> 0
		);

		$this->M_guru->add_nilai($datasiswa);
		$this->session->set_flashdata('notif',' Siswa Berhasil Ditambah !');
		$data['list_siswa'] = $this->M_guru->ambil_siswa($kode_mapel,$kode_kelas);
		$this->load->view('guru/input_nilai',$data);
	}

	public function ubah_nilai($id, $kd_mapel){
		$this->load->model('M_guru');
		$data['list_siswa'] = $this->M_guru->ambil_nilai3($id, $kd_mapel);
		$this->load->view('guru/edit_nilai',$data);
	}

	public function edit_nilai($nis, $kd_mapel){
		$this->load->model('M_guru');

		$nis 					= $this->input->post('nis');
		$kode_mapel 			= $this->input->post('kode_mapel');
		$kode_kelas				= $this->input->post('kode_kelas');
		$nilai_ulangan 			= $this->input->post('nilai_ulangan');
		$nilai_tugas			= $this->input->post('nilai_tugas');
		$nilai_mid				= $this->input->post('nilai_mid');
		$nilai_semester1		= $this->input->post('nilai_semester1');
		$nilai_semester2		= $this->input->post('nilai_semester2');
		$nilai_akhir			= ($nilai_ulangan + $nilai_tugas + $nilai_mid + $nilai_semester1 + $nilai_semester2)/5;

		
		$this->form_validation->set_rules('nilai_ulangan','Nilai','numeric|less_than_equal_to[100]');
		$this->form_validation->set_rules('nilai_tugas','Nilai','numeric|less_than_equal_to[100]');
		$this->form_validation->set_rules('nilai_mid','Nilai','numeric|less_than_equal_to[100]');
		$this->form_validation->set_rules('nilai_semester1','Nilai','numeric|less_than_equal_to[100]');
		$this->form_validation->set_rules('nilai_semester2','Nilai','numeric|less_than_equal_to[100]');

		if ($this->form_validation->run()) {
			$datasiswa = array(
				'nis' 				=> $nis,
				'kode_mapel'		=> $kode_mapel,
				'kode_kelas' 		=> $kode_kelas,
				'nilai_ulangan'		=> $nilai_ulangan,
				'nilai_tugas'		=> $nilai_tugas,
				'nilai_mid'			=> $nilai_mid,
				'nilai_semester1'	=> $nilai_semester1,
				'nilai_semester2'	=> $nilai_semester2,
				'nilai_akhir'		=> $nilai_akhir
			);

			$this->M_guru->edit_nilai($datasiswa, $nis, $kd_mapel);
			$this->session->set_flashdata('notif',' Data Berhasil Diubah !');
	    	$data['list_siswa'] = $this->M_guru->ambil_nilai3($nis, $kd_mapel);
			$this->load->view('guru/edit_nilai', $data);
		}else{
			$data['list_siswa'] = $this->M_guru->ambil_nilai3($nis, $kd_mapel);
			$this->load->view('guru/edit_nilai', $data);
		}		
	}	
}