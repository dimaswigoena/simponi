<?php
class Kelas extends CI_Controller {

	/**
	 * Deskripsi Project :
	 * Nama File  : Controller Kelas
	 * Develop By : @DimasWigoena
	 * Author  By : @DimasWigoena
	 * Tanggal    :
	 * Thanks To  : SMK Utama Bakti Palembang
	 * Versi      : V1.0
	 * STMIK GI MDP Palembang
	 */
	
	
	/**************
	 * Data Kelas *
	 **************/

	#Menampilkan Form Input Data Kelas
	public function input_data_kelas(){
		$this->load->view('admin/input_data_kelas');
	}

	#Menyimpan Data Kelas
	public function add(){
		$this->load->model('Crud_kelas');
		$kode_kelas = $this->input->POST('kd_kelas');
		$nama_kelas = $this->input->POST('nama_kelas');

		$this->form_validation->set_rules('kd_kelas','Kode Kelas','required');
		$this->form_validation->set_rules('nama_kelas','Nama Kelas','required');

		if ($this->form_validation->run()){
			$datainput_kelas = array(
				'kode_kelas' => $kode_kelas,
				'nama_kelas' => $nama_kelas
			);
			$this->Crud_kelas->add_kelas($datainput_kelas);
			$this->session->set_flashdata('notif',' Data Berhasil Disimpan !');
			redirect('admin/tampil_data_kelas');
		}else{
			$this->load->view('admin/input_data_kelas');
		}
	}

	#Menghapus Data Kelas
    public function remove($kode_kelas){
    	$this->load->model('Crud_kelas');
        $ambil = $this->Crud_kelas->ambil_tb_kelas($kode_kelas);

        if(isset($ambil['kode_kelas'])){
            $hapus = $this->Crud_kelas->delete_kelas($kode_kelas);
            if ($hapus == FALSE) {
            	$this->session->set_flashdata('notif',' Data Gagal Di Hapus !');
            	redirect('admin/tampil_data_kelas');
            }else{
            	$this->session->set_flashdata('notif',' Data Berhasil Di Hapus !');
            	redirect('admin/tampil_data_kelas');
            }
            
        }
    }	

	#Merubah Data Kelas
    public function edit($kode_kelas){   
    	$this->load->model('Crud_kelas');
        $data['kelas'] = $this->Crud_kelas->ambil_tb_kelas($kode_kelas);
        
        if(isset($data['kelas']['kode_kelas'])){
        	$this->load->library('form_validation');
			$this->form_validation->set_rules('nama_kelas','Nama kelas','required');
		
			if($this->form_validation->run()){   
                $data_kelas = array(
                	'kode_kelas' => $this->input->post('kd_kelas'),
					'nama_kelas' => $this->input->post('nama_kelas')
                );

                $this->Crud_kelas->update_tb_kelas($kode_kelas,$data_kelas);
                $this->session->set_flashdata('notif',' Data Berhasil Di Ubah !');            
                redirect('admin/tampil_data_kelas');
            }else{
                $this->load->view('admin/edit_data_kelas',$data);
            }
        }
    } 	
}
