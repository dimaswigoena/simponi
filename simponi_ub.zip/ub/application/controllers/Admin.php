<?php
class Admin extends CI_Controller {

	/*
	 * Deskripsi Project :
	 * Nama File  : Controller Admin
	 * Develop By : @DimasWigoena
	 * Author  By : @DimasWigoena
	 * Tanggal    :
	 * Thanks To  : SMK Utama Bakti Palembang
	 * Versi      : V1.0
	 * STMIK GI MDP Palembang
	 */

	public function __construct(){
		parent::__construct();
		if($this->session->userdata('level') <> "1"){
			redirect('Login');
		}
	}

	public function index(){
		$dt['username'] = $this->session->userdata('username');
		$this->load->view('admin/dashboard',$dt);
	}

	public function keluar(){
		$this->session->sess_destroy($dt);
		redirect ('login');
	}

	#Data Siswa
	public function tampil_data_siswa(){
		$this->load->model('Crud_siswa');
		$data_siswa['list_siswa'] = $this->Crud_siswa->tampil_data_siswa();
		$this->load->view('admin/datasiswa', $data_siswa);
	}

	public function lihat_nilai_siswa(){
		$this->load->model('Crud_siswa');
		$data_siswa['list_siswa'] = $this->Crud_siswa->tampil_data_siswa();
		$this->load->view('admin/datanilai', $data_siswa);	
	}

	#Data Siswa Alumni
	public function data_alumni(){
		$this->load->model('Crud_siswa');		
		$data['alumni'] = $this->Crud_siswa->alumni();
		$this->load->view('admin/data_alumni',$data);
	}

	#Data Guru
	public function tampil_data_guru(){
		$this->load->model('Crud_guru');
		$data_guru['list_guru'] = $this->Crud_guru->tampil_data_guru();
		$this->load->view('admin/dataguru',$data_guru);
	}

	#Data Jadwal
	public function tampil_data_jadwal(){
		$this->load->model('Crud_kelas');
		$data_kelas['list_kelas'] = $this->Crud_kelas->tampil_data_kelas();
		$this->load->view('admin/datajadwal',$data_kelas);
	}

	/******************************************
	 * Fungsi Menampilkan Data Mata Pelajaran *
	 ******************************************/
	public function tampil_data_mapel(){
		$this->load->model('Crud_mapel');
		$data_mapel['list_mapel'] = $this->Crud_mapel->tampil_data_mapel();
		$this->load->view('admin/datamatapelajaran',$data_mapel);
	}

	/*********************************** 
	 * Fungsi Menampilkan Data Jurusan *
	 ***********************************/
	public function tampil_data_jurusan(){
		$this->load->model('Crud_jurusan');
		$data_jurusan['list_jurusan'] = $this->Crud_jurusan->tampil_data_jurusan();
		$this->load->view('admin/datajurusan',$data_jurusan);
	}
	
	/*********************************
	 * Fungsi Menampilkan Data Kelas *
	 *********************************/
	public function tampil_data_kelas(){
		$this->load->model('Crud_kelas');
		$data_kelas['list_kelas'] = $this->Crud_kelas->tampil_data_kelas();
		$this->load->view('admin/datakelas',$data_kelas);
	}

	/***********************************
	 * Fungsi Menampilkan Data Ruangan *
	 ***********************************/
	public function tampil_data_ruangan(){
		$this->load->model('Crud_ruangan');
		$data_ruangan['list_ruangan'] = $this->Crud_ruangan->tampil_data_ruangan();
		$this->load->view('admin/dataruangan',$data_ruangan);
	}
	
}
