<?php
class Jurusan extends CI_Controller {

	/*
	 * Deskripsi Project :
	 * Nama File  : Controller Jurusan
	 * Develop By : @DimasWigoena
	 * Author  By : @DimasWigoena
	 * Tanggal    :
	 * Thanks To  : SMK Utama Bakti Palembang
	 * Versi      : V1.0
	 * STMIK GI MDP Palembang
	 */
	
	

	/****************
	 * Data Jurusan *
	 ****************/

	#Menampilkan Form Input Data Jurursan
	public function input_data_jurusan(){
		$this->load->view('admin/input_data_jurusan');
	}

	#Menyimpan Data Jurusan
	public function add(){
		$this->load->model('Crud_jurusan');
		$kode_jurusan = $this->input->POST('kd_jurusan');
		$nama_jurusan = $this->input->POST('nama_jurusan');

		$this->form_validation->set_rules('kd_jurusan','Kode Jurusan','required');
		$this->form_validation->set_rules('nama_jurusan','Nama Jurusan','required');

		if ($this->form_validation->run()){			
			$datainput_jurusan = array(
				'kode_jurusan' => $kode_jurusan,
				'nama_jurusan' => $nama_jurusan
			);

			$this->Crud_jurusan->add_jurusan($datainput_jurusan);
			$this->session->set_flashdata('notif',' Data Berhasil Disimpan !');
			redirect('admin/tampil_data_jurusan');

		}else{
			$this->load->view('admin/input_data_jurusan');
		}		
	}

	#Menghapus Data Jurusan
    public function remove($kode_jurusan){
    	$this->load->model('Crud_jurusan');
        $ambil = $this->Crud_jurusan->ambil_tb_jurusan($kode_jurusan);

        if(isset($ambil['kode_jurusan'])){
            $hapus = $this->Crud_jurusan->delete_jurusan($kode_jurusan);
            if ($hapus == FALSE) {
            	$this->session->set_flashdata('notif',' Data Gagal Di Hapus !');
            	redirect('admin/tampil_data_jurusan');
            }else{
            	$this->session->set_flashdata('notif',' Data Berhasil Di Hapus !');
            	redirect('admin/tampil_data_jurusan');
            }
           
        }
    }	

	#Merubah Data Jurusan
    public function edit($kode_jurusan){
    	$this->load->model('Crud_jurusan');
        $data['jurusan'] = $this->Crud_jurusan->ambil_tb_jurusan($kode_jurusan);
        
        if(isset($data['jurusan']['kode_jurusan'])){
            $this->load->library('form_validation');
			$this->form_validation->set_rules('nama_jurusan','Nama jurusan','required');
		
			if($this->form_validation->run()){   
                $data_jurusan = array(
                    'kode_jurusan' => $this->input->post('kd_jurusan'),
					'nama_jurusan' => $this->input->post('nama_jurusan')
                );

                $this->Crud_jurusan->update_jurusan($kode_jurusan,$data_jurusan);
                $this->session->set_flashdata('notif',' Data Berhasil Di Ubah !');            
                redirect('admin/tampil_data_jurusan');
            }else{
                $this->load->view('admin/edit_data_jurusan',$data);
            }
        }
    } 	
}
