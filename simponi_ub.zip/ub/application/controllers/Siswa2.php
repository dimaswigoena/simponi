<?php
class Siswa2 extends CI_Controller {

	/**
	 * Deskripsi Project :
	 * Nama File  : Controller Siswa2
	 * Develop By : @DimasWigoena
	 * Author  By : @DimasWigoena
	 * Tanggal    :
	 * Thanks To  : SMK Utama Bakti Palembang
	 * Versi      : V1.0
	 * STMIK GI MDP Palembang
	 */
	

	/**************
	 * Data siswa *
	 **************/

	#Menampilkan Form Input Data Siswa
	public function input_data_siswa(){
		$this->load->view('admin/input_data_siswa', array('error' => ' ' ));
	}

	#Menampilkan Data Siswa
	public function datasiswa($nis){
		$this->load->model('Crud_siswa');
		$data['data_siswa'] = $this->Crud_siswa->ambil_tb_siswa($nis);
		$this->load->view('admin/lihat_data_siswa',$data);
	}

	#Menyimpan Data Siswa
	public function add(){
		$this->load->model('Crud_siswa');
		
		$nis 				= $this->input->POST('nis');
		$nama_siswa 		= $this->input->POST('nama_siswa');
		$jurusan			= $this->input->POST('jurusan');
		$kelas 				= $this->input->POST('kelas');
		$jk					= $this->input->POST('jenis_kelamin');
		$status_siswa		= $this->input->POST('status');
		$tempat_lahir		= $this->input->POST('tempat_lahir');
		$tgl_lahir			= $this->input->POST('tgl_lahir');
		$alamat				= $this->input->POST('alamat');
		$nama_ayah			= $this->input->POST('nama_ayah');
		$pekerjaan_ayah		= $this->input->POST('pekerjaan_ayah');
		$nama_ibu			= $this->input->POST('nama_ibu');
		$pekerjaan_ibu		= $this->input->POST('pekerjaan_ibu');
		$telp_siswa			= $this->input->POST('telp_siswa');
		$telp_ortu			= $this->input->POST('telp_ortu');
		$tahun_masuk		= $this->input->POST('tahun_masuk');
		$username			= $this->input->POST('nis');
		$katasandi 			= md5($this->input->POST('password'));


		$this->form_validation->set_rules('nis','NIS','required|numeric');
		$this->form_validation->set_rules('nama_siswa','Nama Siswa','required');
		$this->form_validation->set_rules('jurusan','Jurusan','callback_jur_check');
		$this->form_validation->set_rules('kelas','Kelas','callback_kelas_check');
		$this->form_validation->set_rules('jenis_kelamin','Jenis Kelamin','required');
		$this->form_validation->set_rules('status','Status','required');
		$this->form_validation->set_rules('tempat_lahir','Tempat Lahir','required');
		$this->form_validation->set_rules('tgl_lahir','Tanggal Lahir','required|isset');
		$this->form_validation->set_rules('alamat','Alamat','required');
		$this->form_validation->set_rules('nama_ayah','Nama Ayah','required');
		$this->form_validation->set_rules('pekerjaan_ayah','Pekerjaan Ayah','required');
		$this->form_validation->set_rules('nama_ibu','Nama Ibu','required');
		$this->form_validation->set_rules('pekerjaan_ibu','Pekerjaan Ibu','required');
		$this->form_validation->set_rules('telp_siswa','No Telpon Siswa','required|numeric');
		$this->form_validation->set_rules('telp_ortu',' No Telpon Orang Tua','required|numeric');
		$this->form_validation->set_rules('tahun_masuk','Tahun Masuk','required|numeric|min_length[4]');
		$this->form_validation->set_rules('password','Kata Sandi','required|min_length[6]');
			
			#Upload Gambar
				$config['upload_path']          = 'data/foto/siswa';
		        $config['allowed_types']        = 'jpg|png';
		        $config['max_size']             = 2048;
		        $config['max_width']            = 2048;
		        $config['max_height']           = 2048;

		        $this->upload->initialize($config);
		        $this->load->library('upload', $config);


			if (($this->form_validation->run()==FALSE)&&(!$this->upload->do_upload('foto'))){
        		$error = array('error' => $this->upload->display_errors());
        		$this->load->view('admin/input_data_siswa',$error);
        	}elseif ($this->form_validation->run()==FALSE) {
        		$error = array('error' => $this->upload->display_errors());
        		$this->load->view('admin/input_data_siswa',$error);
        	}
        	elseif (!$this->upload->do_upload('foto')) {
	        	$error = array('error' => $this->upload->display_errors());
	    		$this->load->view('admin/input_data_guru',$error);
        	}else{          	
        		$upload = $this->upload->data();    	
	        	$data = array(
	        		'nama_file'   => $upload['file_name']
	        	);         	
        	
	        	$datasiswa = array(
					'nis' 				=> $nis,
					'nama_siswa'		=> $nama_siswa,
					'kode_jurusan'		=> $jurusan,
					'kode_kelas'		=> $kelas,
					'status'			=> $status_siswa,
				);

				$datadetail = array(
					'nis'				=> $nis,	
					'jenis_kelamin'		=> $jk,
					'tempat_lahir'		=> $tempat_lahir,
					'tanggal_lahir'		=> $tgl_lahir,
					'alamat_siswa'		=> $alamat,
					'nama_ayah'			=> $nama_ayah,
					'pekerjaan_ayah'	=> $pekerjaan_ayah,
					'nama_ibu'			=> $nama_ibu,
					'pekerjaan_ibu'		=> $pekerjaan_ibu,
					'tlp_siswa'			=> $telp_siswa,
					'tlp_ortu'			=> $telp_ortu,
					'tahun_masuk'		=> $tahun_masuk,
					'foto'				=> $data['nama_file']
				);

				$datalogin = array(
					'username' 	=> $username,
					'katasandi' => $katasandi,
					'level'		=> 3
				);

				$this->Crud_siswa->add_data('tb_siswa', $datasiswa);
				$this->Crud_siswa->add_data('tb_detailsiswa', $datadetail);
				$this->Crud_siswa->add_data('tb_login', $datalogin);
				$this->session->set_flashdata('notif',' Data Berhasil Disimpan !');
				redirect('admin/tampil_data_siswa');
	        }		
	}

	#Menampilkan Form Edit Data Siswa
	public function edit_data_siswa($nis){
		$this->load->model('Crud_siswa');
		$data_siswa['data_siswa'] = $this->Crud_siswa->ambil_tb_siswa($nis);
		$this->load->view('admin/edit_data_siswa',$data_siswa);
	}

	#Edit Data Siswa
	public function update($nis){
		$this->load->model('Crud_siswa');
		
		$nama_siswa 		= $this->input->POST('nama_siswa');
		$jurusan			= $this->input->POST('jurusan');
		$kelas 				= $this->input->POST('kelas');
		$jk					= $this->input->POST('jenis_kelamin');
		$status_siswa		= $this->input->POST('status');
		$tempat_lahir		= $this->input->POST('tempat_lahir');
		$tgl_lahir			= $this->input->POST('tgl_lahir');
		$alamat				= $this->input->POST('alamat');
		$nama_ayah			= $this->input->POST('nama_ayah');
		$pekerjaan_ayah		= $this->input->POST('pekerjaan_ayah');
		$nama_ibu			= $this->input->POST('nama_ibu');
		$pekerjaan_ibu		= $this->input->POST('pekerjaan_ibu');
		$telp_siswa			= $this->input->POST('telp_siswa');
		$telp_ortu			= $this->input->POST('telp_ortu');
		$tahun_masuk		= $this->input->POST('tahun_masuk');
		$username			= $this->input->POST('nis');
		$katasandi 			= md5($this->input->POST('password'));
		$foto_lama			= $this->input->POST('foto_lama');

		$this->form_validation->set_rules('nama_siswa','Nama Siswa','required');
		$this->form_validation->set_rules('jurusan','Jurusan','callback_jur_check');
		$this->form_validation->set_rules('kelas','Kelas','callback_kelas_check');
		$this->form_validation->set_rules('jenis_kelamin','Jenis Kelamin','required');
		$this->form_validation->set_rules('status','Status','required');
		$this->form_validation->set_rules('tempat_lahir','Tempat Lahir','required');
		$this->form_validation->set_rules('tgl_lahir','Tanggal Lahir','required|isset');
		$this->form_validation->set_rules('alamat','Alamat','required');
		$this->form_validation->set_rules('nama_ayah','Nama Ayah','required');
		$this->form_validation->set_rules('pekerjaan_ayah','Pekerjaan Ayah','required');
		$this->form_validation->set_rules('nama_ibu','Nama Ibu','required');
		$this->form_validation->set_rules('pekerjaan_ibu','Pekerjaan Ibu','required');
		$this->form_validation->set_rules('telp_siswa','No Telpon Siswa','required|numeric');
		$this->form_validation->set_rules('telp_ortu',' No Telpon Orang Tua','required|numeric');
		$this->form_validation->set_rules('tahun_masuk','Tahun Masuk','required|numeric|min_length[4]');
		$this->form_validation->set_rules('password','Kata Sandi','required|min_length[6]');

		#Upload Gambar
		$config['upload_path']          = 'data/foto/siswa';
        $config['allowed_types']        = 'jpg|png';
        $config['max_size']             = 2048;
        $config['max_width']            = 2048;
        $config['max_height']           = 2048;

        $this->upload->initialize($config);
        $this->load->library('upload', $config);

	    
    	if ((!$this->upload->do_upload('foto_baru'))){
			$error = array('error' => $this->upload->display_errors());
		}else{
			$ambil = $this->Crud_siswa->ambil_tb_siswa($nis);
			$path = 'data/foto/siswa/'.$ambil['foto'];
			unlink($path);          	
    		$upload = $this->upload->data();    	
        	$foto_lama = $upload['file_name'];
		}	    
	    	$datasiswa = array(
				'nis' 				=> $nis,
				'nama_siswa'		=> $nama_siswa,
				'kode_jurusan'		=> $jurusan,
				'kode_kelas'		=> $kelas,
				'status'			=> $status_siswa,
			);

			$datadetail = array(
				'nis'				=> $nis,	
				'jenis_kelamin'		=> $jk,
				'tempat_lahir'		=> $tempat_lahir,
				'tanggal_lahir'		=> $tgl_lahir,
				'alamat_siswa'		=> $alamat,
				'nama_ayah'			=> $nama_ayah,
				'pekerjaan_ayah'	=> $pekerjaan_ayah,
				'nama_ibu'			=> $nama_ibu,
				'pekerjaan_ibu'		=> $pekerjaan_ibu,
				'tlp_siswa'			=> $telp_siswa,
				'tlp_ortu'			=> $telp_ortu,
				'tahun_masuk'		=> $tahun_masuk,
				'foto'				=> $foto_lama
			);

			$datalogin = array(
				'username' 	=> $username
			);

			$this->Crud_siswa->update_siswa($datasiswa,$nis);
			$this->Crud_siswa->update_detailsiswa($datadetail,$nis);
			$this->Crud_siswa->update_login($datalogin,$nis);
			$this->session->set_flashdata('notif',' Data Berhasil Di Ubah !');
			$this->load->model('Crud_siswa');
			$data_siswa['data_siswa'] = $this->Crud_siswa->ambil_tb_siswa($nis);
			$this->load->view('admin/edit_data_siswa',$data_siswa);
	}

	#Kata Sandi
	public function ubah_katasandi($username){
		$this->load->model('Crud_siswa');
		$data['user'] = $this->Crud_siswa->ambil_tb_login($username);
		$this->load->view('admin/ubah_katasandi_siswa',$data);
	}

	public function ganti_sandi($username){
		$this->load->model('Crud_siswa');
		$data['user'] = $this->Crud_siswa->ambil_tb_login($username);
		
		if(isset($data['user']['username'])){
        	$password1 = md5($this->input->post('password1'));
        	$password2 = md5($this->input->post('password2'));
			$this->form_validation->set_rules('password1','Password Baru','required');
			
			if ($password1 != $password2){
				$this->session->set_flashdata('notif','Password Tidak Sama, Silahkan Ulangi !');
				$this->load->view('admin/ubah_katasandi_siswa',$data);
			}elseif ($this->form_validation->run()) {
				$data_baru = array(
					'username' => $username,
					'katasandi' => md5($this->input->post("password2"))
					);
				$this->Crud_siswa->update_login($username,$data_baru);
                $this->session->set_flashdata('notif',' Kata Sandi Berhasil Di Ubah !');           
                redirect('admin/tampil_data_siswa');
			}else{   
                $this->load->view('admin/ubah_katasandi_siswa',$data);
            }
        }else{
            $this->load->view('admin/tampil_data_siswa',$data);
        }
	}

	#Data Jadwal
	public function lihatjadwal(){
		$this->load->view('admin/lihat_data_jadwal');
	}

	#Data Siswa Alumni
	public function data_alumni(){
		$this->load->model('Crud_siswa');		
		$data['cari'] = $this->Crud_siswa->alumni($cari);
		$this->load->view('admin/data_alumni',$data);
	}

	#Cari Data Nilai
	public function cari_nilai(){
		$this->load->model('Crud_siswa');
		$cari = $this->input->POST('cari');		
		$data['cari'] = $this->Crud_siswa->cari($cari);
		$this->load->view('admin/cari_nilai',$data);
	}

	#Data Nilai Siswa
	public function datanilai($nis){
		$this->load->model('Crud_siswa');
		$data['data_nilai'] = $this->Crud_siswa->ambil_tb_nilai($nis);
		$this->load->view('admin/lihat_nilai_siswa',$data);
	}

	#Cek Combobox Data Jurusan
	public function jur_check($jur){
		if ($jur == 'none'){
			$this->form_validation->set_message('jur_check','Silahkan Pilih Jurusan');
			return FALSE;
		}else{
			return TRUE;
		}
	}

	#Cek Combobox Data Kelas
	public function kelas_check($kelas)
	{
		if ($kelas == 'none'){
			$this->form_validation->set_message('kelas_check','Silahkan Pilih Kelas');
			return FALSE;
		}else{
			return TRUE;
		}
	}
}
