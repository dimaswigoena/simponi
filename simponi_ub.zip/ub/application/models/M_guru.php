<?php
class M_guru extends CI_Model {

    #Fungsi ambil data guru by kode guru
    public function ambil_tb_guru($kode_guru){
        $query = 
            "SELECT
                tb_guru.kode_guru,
                tb_guru.nama_guru,
                tb_guru.`status`,
                tb_detailguru.jenis_kelamin,
                tb_detailguru.alamat,
                tb_detailguru.tempat_lahir,
                tb_detailguru.tanggal_lahir,
                tb_detailguru.no_tlp,
                tb_detailguru.tmt,
                tb_detailguru.foto,
                tb_matapelajaran.nama_mapel,
                tb_matapelajaran.kode_mapel
            FROM
                tb_guru
            INNER JOIN tb_detailguru ON tb_detailguru.kode_guru = tb_guru.kode_guru
            INNER JOIN tb_matapelajaran ON tb_guru.kode_mapel = tb_matapelajaran.kode_mapel
            WHERE
                tb_guru.kode_guru = tb_detailguru.kode_guru
            AND tb_guru.kode_mapel = tb_matapelajaran.kode_mapel
            AND ".$kode_guru." = tb_guru.kode_guru";
        return $this->db->query($query)->row_array();
    }

    #Fungsi ambil jadwal
    public function ambiljadwal($kd_guru){
        $query = 
            "SELECT
                tb_jadwal.jamke,
                tb_jadwal.jam,
                tb_kelas.kode_kelas,
                tb_kelas.nama_kelas,
                tb_hari.nama_hari,
                tb_matapelajaran.kode_mapel,
                tb_matapelajaran.nama_mapel,
                tb_guru.nama_guru,
                tb_ruangan.nama_ruangan
            FROM
                tb_jadwal
            INNER JOIN tb_kelas ON tb_kelas.kode_kelas = tb_jadwal.kode_kelas
            INNER JOIN tb_matapelajaran ON tb_jadwal.kode_mapel = tb_matapelajaran.kode_mapel
            INNER JOIN tb_guru ON tb_jadwal.kode_guru = tb_guru.kode_guru
            INNER JOIN tb_ruangan ON tb_jadwal.kode_ruangan = tb_ruangan.kode_ruangan
            INNER JOIN tb_hari ON tb_jadwal.kode_hari = tb_hari.kode_hari
            WHERE
                tb_jadwal.kode_mapel = tb_matapelajaran.kode_mapel
            AND tb_jadwal.kode_guru = tb_guru.kode_guru
            AND tb_jadwal.kode_ruangan = tb_ruangan.kode_ruangan
            AND tb_jadwal.kode_hari = tb_hari.kode_hari
            AND tb_guru.kode_guru = ".$kd_guru."
            ORDER BY
                tb_jadwal.kode_hari ASC";
        return $this->db->query($query)->result_array();
    }

    #Fungsi ambil jadwal
    public function ambiljadwal2($kd_guru){
        $query = 
            "SELECT
                tb_jadwal.jamke,
                tb_jadwal.jam,
                tb_kelas.kode_kelas,
                tb_kelas.nama_kelas,
                tb_hari.nama_hari,
                tb_matapelajaran.kode_mapel,
                tb_matapelajaran.nama_mapel,
                tb_guru.nama_guru,
                tb_ruangan.nama_ruangan
            FROM
                tb_jadwal
            INNER JOIN tb_kelas ON tb_kelas.kode_kelas = tb_jadwal.kode_kelas
            INNER JOIN tb_matapelajaran ON tb_jadwal.kode_mapel = tb_matapelajaran.kode_mapel
            INNER JOIN tb_guru ON tb_jadwal.kode_guru = tb_guru.kode_guru
            INNER JOIN tb_ruangan ON tb_jadwal.kode_ruangan = tb_ruangan.kode_ruangan
            INNER JOIN tb_hari ON tb_jadwal.kode_hari = tb_hari.kode_hari
            WHERE
                tb_jadwal.kode_mapel = tb_matapelajaran.kode_mapel
            AND tb_jadwal.kode_guru = tb_guru.kode_guru
            AND tb_jadwal.kode_ruangan = tb_ruangan.kode_ruangan
            AND tb_jadwal.kode_hari = tb_hari.kode_hari
            AND tb_guru.kode_guru = ".$kd_guru."
            GROUP BY
                tb_kelas.kode_kelas";
        return $this->db->query($query)->result_array();
    }

    public function ambil_nilai($kd_mapel, $kd_kelas){

        $query = 
        "SELECT
            tb_nilai.id,
            tb_siswa.nis,
            tb_siswa.nama_siswa,
            tb_nilai.nilai_ulangan,
            tb_nilai.nilai_tugas,
            tb_nilai.nilai_mid,
            tb_nilai.nilai_semester1,
            tb_nilai.nilai_semester2,
            tb_nilai.nilai_akhir,
            tb_matapelajaran.nama_mapel,
            tb_kelas.nama_kelas
            tb_ke
        FROM
            tb_nilai
        INNER JOIN tb_siswa ON tb_nilai.nis = tb_siswa.nis
        INNER JOIN tb_matapelajaran ON tb_nilai.kode_mapel = tb_matapelajaran.kode_mapel
        INNER JOIN tb_kelas ON tb_nilai.kode_kelas = tb_kelas.kode_kelas
        WHERE
            tb_nilai.nis = tb_siswa.nis
        AND tb_nilai.kode_mapel = tb_matapelajaran.kode_mapel
        AND tb_nilai.kode_kelas = tb_kelas.kode_kelas
        AND tb_nilai.kode_kelas = '".$kd_kelas."'
        AND tb_nilai.kode_mapel = '".$kd_mapel."'
        ORDER BY
            tb_nilai.nis ASC";

        return $this->db->query($query)->result_array();
    }

    public function ambil_nilai2($nis){
        $query = 
        "SELECT
            tb_nilai.id,
            tb_nilai.kode_kelas,
            tb_nilai.kode_mapel,
            tb_siswa.nis,
            tb_siswa.nama_siswa,
            tb_nilai.nilai_ulangan,
            tb_nilai.nilai_tugas,
            tb_nilai.nilai_mid,
            tb_nilai.nilai_semester1,
            tb_nilai.nilai_semester2,
            tb_nilai.nilai_akhir,
            tb_matapelajaran.nama_mapel,
            tb_kelas.nama_kelas
        FROM
            tb_nilai
        INNER JOIN tb_siswa ON tb_nilai.nis = tb_siswa.nis
        INNER JOIN tb_matapelajaran ON tb_nilai.kode_mapel = tb_matapelajaran.kode_mapel
        INNER JOIN tb_kelas ON tb_nilai.kode_kelas = tb_kelas.kode_kelas
        WHERE
            tb_nilai.nis = tb_siswa.nis
        AND tb_nilai.kode_mapel = tb_matapelajaran.kode_mapel
        AND tb_nilai.kode_kelas = tb_kelas.kode_kelas
        AND tb_nilai.nis = '".$nis."'";

        return $this->db->query($query)->row_array();
       
    }

    public function ambil_nilai3($nis, $kode_mapel){
        $query = 
        "SELECT
            tb_nilai.id,
            tb_nilai.kode_kelas,
            tb_nilai.kode_mapel,
            tb_siswa.nis,
            tb_siswa.nama_siswa,
            tb_nilai.nilai_ulangan,
            tb_nilai.nilai_tugas,
            tb_nilai.nilai_mid,
            tb_nilai.nilai_semester1,
            tb_nilai.nilai_semester2,
            tb_nilai.nilai_akhir,
            tb_matapelajaran.nama_mapel,
            tb_kelas.nama_kelas
        FROM
            tb_nilai
        INNER JOIN tb_siswa ON tb_nilai.nis = tb_siswa.nis
        INNER JOIN tb_matapelajaran ON tb_nilai.kode_mapel = tb_matapelajaran.kode_mapel
        INNER JOIN tb_kelas ON tb_nilai.kode_kelas = tb_kelas.kode_kelas
        WHERE
            tb_nilai.nis = tb_siswa.nis
        AND tb_nilai.kode_mapel = tb_matapelajaran.kode_mapel
        AND tb_nilai.kode_kelas = tb_kelas.kode_kelas
        AND tb_nilai.nis = '".$nis."'
        AND tb_nilai.kode_mapel = '".$kode_mapel."'";

        return $this->db->query($query)->row_array();
       
    }

    public function ambil_siswa($kd_mapel, $kd_kelas){
        $query = 
        "SELECT
            tb_siswa.nis,
            tb_siswa.nama_siswa,
            tb_siswa.kode_kelas,
            tb_jurusan.nama_jurusan,
            tb_kelas.nama_kelas,
            tb_siswa.`status`
        FROM
            tb_siswa
        INNER JOIN tb_jurusan ON tb_siswa.kode_jurusan = tb_jurusan.kode_jurusan
        INNER JOIN tb_kelas ON tb_siswa.kode_kelas = tb_kelas.kode_kelas
        WHERE
            tb_siswa.kode_jurusan = tb_jurusan.kode_jurusan
        AND tb_siswa.kode_kelas = tb_kelas.kode_kelas
        AND tb_siswa.kode_kelas = '".$kd_kelas."'
        ORDER BY
            tb_siswa.nis ASC";
        return $this->db->query($query)->result_array();
    }


    #Fungsi update login
    public function update_tb_login($username, $newpassword){
        $this->db->where('username',$username);
        return $this->db->update('tb_login',$newpassword);
    }

    #Fungsi ambil tb_login by username 
    public function ambil_tb_login($username){
        return $this->db->get_where('tb_login',array('username'=>$username))->row_array();
    }

    #Fungsi ambil tb_materi by kode_mapel & kd_kelas
    public function ambilmateri($kd_mapel, $kd_kelas){
        $this->db->order_by('id', 'ASC');
        return $this->db->get_where('tb_materi',array('kode_mapel'=>$kd_mapel,'kode_kelas'=>$kd_kelas))->result_array();
    }

    public function ambilmateri1($kd_mapel, $kd_kelas){
        return $this->db->get_where('tb_jadwal',array('kode_mapel'=>$kd_mapel,'kode_kelas'=>$kd_kelas))->row_array();
    }

    public function ambilmateri2($id){
        $this->db->order_by('id', 'ASC');
        return $this->db->get_where('tb_materi',array('id'=>$id))->row_array();
    }


    public function add_materi($data){
        $this->db->insert('tb_materi',$data);
    }

    public function edit_materi($datamateri, $id){
        $this->db->where('id',$id);
        return $this->db->update('tb_materi',$datamateri);
    }

    public function delete_materi($id){
        $response = $this->db->delete('tb_materi',array('id'=>$id));
    }

    public function add_nilai($data){
        $this->db->insert('tb_nilai',$data);
    }

     public function edit_nilai($data, $nis, $kode_mapel){
        $this->db->where('nis',$nis);
        $this->db->where('kode_mapel', $kode_mapel);
        return $this->db->update('tb_nilai',$data);
    }
}