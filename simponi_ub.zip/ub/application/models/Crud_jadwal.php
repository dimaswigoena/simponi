<?php
class Crud_jadwal extends CI_Model {
 
	#Fungsi Ambil tb_kelas
    public function ambil_kelas($kode){
    	return $this->db->get_where('tb_kelas',array('kode_kelas'=>$kode))->row_array();    	
    }

    #Fungsi Ambil tb_jadwal
    public function ambil_jadwal($kode_kelas){
    	$query =
		  	"SELECT
		  		tb_jadwal.id,
				tb_jadwal.kode_hari,
				tb_jadwal.jamke,
				tb_jadwal.jam,
				tb_matapelajaran.nama_mapel,
				tb_ruangan.nama_ruangan,
				tb_guru.nama_guru,
				tb_kelas.kode_kelas,
				tb_kelas.nama_kelas,
				tb_hari.nama_hari
			FROM
				tb_jadwal
			INNER JOIN tb_matapelajaran ON tb_jadwal.kode_mapel = tb_matapelajaran.kode_mapel
			INNER JOIN tb_ruangan ON tb_jadwal.kode_ruangan = tb_ruangan.kode_ruangan
			INNER JOIN tb_guru ON tb_jadwal.kode_guru = tb_guru.kode_guru
			INNER JOIN tb_kelas ON tb_jadwal.kode_kelas = tb_kelas.kode_kelas
			INNER JOIN tb_hari ON tb_jadwal.kode_hari = tb_hari.kode_hari
			WHERE
				tb_jadwal.kode_mapel = tb_matapelajaran.kode_mapel
			AND tb_jadwal.kode_guru = tb_guru.kode_guru
			AND tb_jadwal.kode_ruangan = tb_ruangan.kode_ruangan
			AND tb_jadwal.kode_kelas = tb_kelas.kode_kelas
			AND tb_jadwal.kode_kelas = '".$kode_kelas."'
			ORDER BY
				tb_jadwal.kode_hari ASC,
				tb_jadwal.jamke ASC";   	
    	
		return $this->db->query($query)->result_array();
    }

    #Fungsi Ambil tb_kelas
    public function ambil_all_jadwal($id){
    	return $this->db->get_where('tb_jadwal',array('id'=>$id))->row_array();    	
    }

    #Fungsi Tambah Jadwal
    public function add_jadwal($data){
    	 $this->db->insert('tb_jadwal',$data);
    }

    #Fungsi Hapus Jadwal
    public function delete_jadwal($data){
    	 $response = $this->db->delete('tb_jadwal',array('id'=>$data));
    }
}