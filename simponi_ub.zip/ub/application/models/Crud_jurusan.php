<?php 
class Crud_jurusan extends CI_Model {
        
    #Fungsi ambil data jurusan by kode_jurusan
    public function ambil_tb_jurusan($kode_jurusan){
        return $this->db->get_where('tb_jurusan',array('kode_jurusan'=>$kode_jurusan))->row_array();
    }
    
    #Fungsi ambil semua data jurusan
    public function tampil_data_jurusan(){
        $this->db->order_by('kode_jurusan','asc');
        return $this->db->get('tb_jurusan')->result_array();
    }
    
    #Fungsi tambah jurusan
    public function add_jurusan($data){
        $this->db->insert('tb_jurusan',$data);
    }

    #Fungsi hapus jurusan
    public function delete_jurusan($kode_jurusan){
        $response = $this->db->delete('tb_jurusan',array('kode_jurusan'=>$kode_jurusan));
        if (!$response) {
          return FALSE;
        }else {
          return TRUE;
        }
    }
    
    #Fungsi update jurusan
    public function update_jurusan($kode_jurusan,$data_jurusan){
        $this->db->where('kode_jurusan',$kode_jurusan);
        return $this->db->update('tb_jurusan',$data_jurusan);
    }    
}