<?php
class Crud_siswa extends CI_Model {

    #Fungsi ambil tb_login by username
    public function ambil_tb_login($username){
        return $this->db->get_where('tb_login',array('username'=>$username))->row_array();
    }
    
    #Fungsi ambil data siswa by kode_siswa
    public function ambil_tb_siswa($nis){        
        $query = 
            "SELECT
                tb_siswa.nis,
                tb_siswa.nama_siswa,
                tb_siswa.`status`,
                tb_detailsiswa.jenis_kelamin,
                tb_detailsiswa.tempat_lahir,
                tb_detailsiswa.tanggal_lahir,
                tb_detailsiswa.alamat_siswa,
                tb_detailsiswa.nama_ayah,
                tb_detailsiswa.pekerjaan_ayah,
                tb_detailsiswa.nama_ibu,
                tb_detailsiswa.pekerjaan_ibu,
                tb_detailsiswa.tlp_siswa,
                tb_detailsiswa.tlp_ortu,
                tb_detailsiswa.tahun_masuk,
                tb_detailsiswa.foto,
                tb_kelas.kode_kelas,
                tb_kelas.nama_kelas,
                tb_jurusan.nama_jurusan,
                tb_jurusan.kode_jurusan
            FROM
                tb_siswa
            INNER JOIN tb_detailsiswa ON tb_detailsiswa.nis = tb_siswa.nis
            INNER JOIN tb_kelas ON tb_siswa.kode_kelas = tb_kelas.kode_kelas
            INNER JOIN tb_jurusan ON tb_siswa.kode_jurusan = tb_jurusan.kode_jurusan
            WHERE
                tb_siswa.nis = tb_detailsiswa.nis
            AND tb_siswa.kode_jurusan = tb_jurusan.kode_jurusan
            AND tb_siswa.kode_kelas = tb_kelas.kode_kelas
            AND ".$nis." = tb_siswa.nis";
        
        return $this->db->query($query)->row_array();
    }
    
    #Fungsi ambil nis,nama,jurusan dan kelas siswa
    public function tampil_data_siswa(){
        $query = 
            "SELECT
                tb_siswa.nis,
                tb_siswa.nama_siswa,
                tb_jurusan.nama_jurusan,
                tb_kelas.nama_kelas,
                tb_siswa.`status`
            FROM
                tb_siswa
            INNER JOIN tb_jurusan ON tb_siswa.kode_jurusan = tb_jurusan.kode_jurusan
            INNER JOIN tb_kelas ON tb_siswa.kode_kelas = tb_kelas.kode_kelas
            WHERE
                tb_siswa.kode_jurusan = tb_jurusan.kode_jurusan
            AND tb_siswa.kode_kelas = tb_kelas.kode_kelas
            AND tb_siswa.`status` = 1
            OR tb_siswa.`status` = 0
            ORDER BY
                tb_siswa.nis ASC";
        
        return $this->db->query($query)->result_array();
    }

    #Fungsi Cari siswa by nama & nis
    public function alumni()
    {
        $query = 
            "SELECT
                tb_siswa.nis,
                tb_siswa.nama_siswa,
                tb_jurusan.nama_jurusan,
                tb_kelas.nama_kelas,
                tb_siswa.`status`
            FROM
                tb_siswa
            INNER JOIN tb_jurusan ON tb_siswa.kode_jurusan = tb_jurusan.kode_jurusan
            INNER JOIN tb_kelas ON tb_siswa.kode_kelas = tb_kelas.kode_kelas
            WHERE
                tb_siswa.kode_jurusan = tb_jurusan.kode_jurusan
            AND tb_siswa.kode_kelas = tb_kelas.kode_kelas
            AND tb_siswa.`status` = 2
            ORDER BY
                tb_siswa.nis ASC";
        
        return $this->db->query($query)->result_array();
    }

    public function ambil_tb_nilai($nis){

        $query = 
        "SELECT
            tb_nilai.id,
            tb_siswa.nis,
            tb_siswa.nama_siswa,
            tb_nilai.nilai_ulangan,
            tb_nilai.nilai_tugas,
            tb_nilai.nilai_mid,
            tb_nilai.nilai_semester1,
            tb_nilai.nilai_semester2,
            tb_nilai.nilai_akhir,
            tb_matapelajaran.nama_mapel,
            tb_kelas.nama_kelas
        FROM
            tb_nilai
        INNER JOIN tb_siswa ON tb_nilai.nis = tb_siswa.nis
        INNER JOIN tb_matapelajaran ON tb_nilai.kode_mapel = tb_matapelajaran.kode_mapel
        INNER JOIN tb_kelas ON tb_nilai.kode_kelas = tb_kelas.kode_kelas
        WHERE
            tb_nilai.nis = tb_siswa.nis
        AND tb_nilai.kode_mapel = tb_matapelajaran.kode_mapel
        AND tb_nilai.kode_kelas = tb_kelas.kode_kelas
        AND tb_nilai.nis = ".$nis."
        ORDER BY
            tb_nilai.kode_kelas ASC";

        return $this->db->query($query)->result_array();
    }

    #Fungsi ambil semua data detail siswa
    public function tampil_detail_siswa(){
        $this->db->order_by('kode_siswa','asc');
        return $this->db->get('tb_detail_siswa')->result_array();
    }
    
    #Fungsi tambah siswa, detail siswa, dan data login
    public function add_data($table, $data){
        $query = $this->db->insert($table,$data);
        return $query;
    }

    #Fungsi hapus siswa
    public function delete_siswa($kode_siswa){
        $response = $this->db->delete('tb_siswa',array('kode_siswa'=>$kode_siswa));
    }
    
    #Fungsi update tb_siswa
    public function update_siswa($datasiswa,$nis){
        $this->db->where('nis',$nis);
        return $this->db->update('tb_siswa',$datasiswa);
    }

    #Fungsi update tb_detailsiswa
    public function update_detailsiswa($detailsiswa,$nis){
        $this->db->where('nis',$nis);
        return $this->db->update('tb_detailsiswa',$detailsiswa);
    }

    #Fungsi Update tb_login
    public function update_login($datalogin,$nis){
        $this->db->where('username',$nis);
        return $this->db->update('tb_login',$datalogin);
    }

    #Fungsi update login
    public function update_tb_login($username,$newpassword){
        $this->db->where('username',$username);
        return $this->db->update('tb_login',$newpassword);
    }
    
}
