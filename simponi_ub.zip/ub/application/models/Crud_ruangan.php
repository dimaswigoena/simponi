<?php
class Crud_ruangan extends CI_Model {

    #Fungsi ambil data ruangan by kode_ruangan
    public function ambil_tb_ruangan($kode_ruangan){
        return $this->db->get_where('tb_ruangan',array('kode_ruangan'=>$kode_ruangan))->row_array();
    }

    #Fungsi ambil semua data ruangan
    public function tampil_data_ruangan(){
        $this->db->order_by('kode_ruangan','asc');
        return $this->db->get('tb_ruangan')->result_array();
    }

    #Fungsi tambah ruangan
    public function add_ruangan($data){
        $this->db->insert('tb_ruangan',$data);
    }

    #Fungsi hapus ruangan
    public function delete_ruangan($kode_ruangan){
        $response = $this->db->delete('tb_ruangan',array('kode_ruangan'=>$kode_ruangan));
        if (!$response) {
          return FALSE;
        }else {
          return TRUE;
        }
    }

    #Fungsi update ruangan
    public function update_ruangan($kode_ruangan,$data_ruangan){
        $this->db->where('kode_ruangan',$kode_ruangan);
        return $this->db->update('tb_ruangan',$data_ruangan);
    }
}
