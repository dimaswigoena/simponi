<?php
class Validasi extends CI_Model {

	/**
	 * Deskripsi Project :
	 * Nama File  : Model Validasi Login
	 * Develop By : @DimasWigoena
	 * Author  By : @DimasWigoena
	 * Tanggal    :
	 * Thanks To  : SMK Utama Bakti Palembang
	 * Versi      : V1.0
	 * STMIK GI MDP Palembang
	 */

	public function cek_login($username, $katasandi){
		$this->db->where('username',$username);
		$this->db->where('katasandi',$katasandi);
		return $this->db->get('tb_login');
	}

}