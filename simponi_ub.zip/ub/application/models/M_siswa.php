<?php
class M_siswa extends CI_Model {

    #Fungsi ambil data siswa by kode_siswa
    public function ambil_tb_siswa($nis){        
        $query = 
            "SELECT
                tb_siswa.nis,
                tb_siswa.kode_kelas,
                tb_siswa.nama_siswa,
                tb_siswa.`status`,
                tb_detailsiswa.jenis_kelamin,
                tb_detailsiswa.tempat_lahir,
                tb_detailsiswa.tanggal_lahir,
                tb_detailsiswa.alamat_siswa,
                tb_detailsiswa.nama_ayah,
                tb_detailsiswa.pekerjaan_ayah,
                tb_detailsiswa.nama_ibu,
                tb_detailsiswa.pekerjaan_ibu,
                tb_detailsiswa.tlp_siswa,
                tb_detailsiswa.tlp_ortu,
                tb_detailsiswa.tahun_masuk,
                tb_detailsiswa.foto,
                tb_kelas.nama_kelas,
                tb_jurusan.nama_jurusan
            FROM
                tb_siswa
            INNER JOIN tb_detailsiswa ON tb_detailsiswa.nis = tb_siswa.nis
            INNER JOIN tb_kelas ON tb_siswa.kode_kelas = tb_kelas.kode_kelas
            INNER JOIN tb_jurusan ON tb_siswa.kode_jurusan = tb_jurusan.kode_jurusan
            WHERE
                tb_siswa.nis = tb_detailsiswa.nis
            AND tb_siswa.kode_jurusan = tb_jurusan.kode_jurusan
            AND tb_siswa.kode_kelas = tb_kelas.kode_kelas
            AND ".$nis." = tb_siswa.nis";
        
        return $this->db->query($query)->row_array();
    }

    #Fungsi ambil jadwal
    public function ambiljadwal($nis)
    {
        $query = 
            "SELECT
                tb_jadwal.kode_mapel,
                tb_jadwal.kode_kelas,
                tb_jadwal.jamke,
                tb_jadwal.jam,
                tb_hari.nama_hari,
                tb_matapelajaran.nama_mapel,
                tb_guru.nama_guru,
                tb_ruangan.nama_ruangan
            FROM
                tb_jadwal
            INNER JOIN tb_siswa ON tb_siswa.kode_kelas = tb_jadwal.kode_kelas
            INNER JOIN tb_matapelajaran ON tb_jadwal.kode_mapel = tb_matapelajaran.kode_mapel
            INNER JOIN tb_guru ON tb_jadwal.kode_guru = tb_guru.kode_guru
            INNER JOIN tb_ruangan ON tb_jadwal.kode_ruangan = tb_ruangan.kode_ruangan
            INNER JOIN tb_hari ON tb_jadwal.kode_hari = tb_hari.kode_hari
            WHERE
                tb_jadwal.kode_kelas = tb_siswa.kode_kelas
            AND tb_jadwal.kode_mapel = tb_matapelajaran.kode_mapel
            AND tb_jadwal.kode_guru = tb_guru.kode_guru
            AND tb_jadwal.kode_ruangan = tb_ruangan.kode_ruangan
            AND tb_jadwal.kode_hari = tb_hari.kode_hari
            AND tb_siswa.nis = ".$nis."";
        return $this->db->query($query)->result_array();
    }

    #Fungsi ambil jadwal
    public function ambiljadwal2($nis)
    {
        $query = 
            "SELECT
                tb_jadwal.kode_mapel,
                tb_jadwal.kode_kelas,
                tb_jadwal.jamke,
                tb_jadwal.jam,
                tb_hari.nama_hari,
                tb_matapelajaran.nama_mapel,
                tb_guru.nama_guru,
                tb_ruangan.nama_ruangan
            FROM
                tb_jadwal
            INNER JOIN tb_siswa ON tb_siswa.kode_kelas = tb_jadwal.kode_kelas
            INNER JOIN tb_matapelajaran ON tb_jadwal.kode_mapel = tb_matapelajaran.kode_mapel
            INNER JOIN tb_guru ON tb_jadwal.kode_guru = tb_guru.kode_guru
            INNER JOIN tb_ruangan ON tb_jadwal.kode_ruangan = tb_ruangan.kode_ruangan
            INNER JOIN tb_hari ON tb_jadwal.kode_hari = tb_hari.kode_hari
            WHERE
                tb_jadwal.kode_kelas = tb_siswa.kode_kelas
            AND tb_jadwal.kode_mapel = tb_matapelajaran.kode_mapel
            AND tb_jadwal.kode_guru = tb_guru.kode_guru
            AND tb_jadwal.kode_ruangan = tb_ruangan.kode_ruangan
            AND tb_jadwal.kode_hari = tb_hari.kode_hari
            AND tb_siswa.nis = ".$nis."
            GROUP BY
                tb_matapelajaran.nama_mapel";
        return $this->db->query($query)->result_array();
    }

    public function ambil_tb_nilai($kode_kelas, $nis){

        $query = 
        "SELECT
            tb_nilai.id,
            tb_siswa.nis,
            tb_siswa.nama_siswa,
            tb_nilai.nilai_ulangan,
            tb_nilai.nilai_tugas,
            tb_nilai.nilai_mid,
            tb_nilai.nilai_semester1,
            tb_nilai.nilai_semester2,
            tb_nilai.nilai_akhir,
            tb_matapelajaran.nama_mapel,
            tb_kelas.nama_kelas
        FROM
            tb_nilai
        INNER JOIN tb_siswa ON tb_nilai.nis = tb_siswa.nis
        INNER JOIN tb_matapelajaran ON tb_nilai.kode_mapel = tb_matapelajaran.kode_mapel
        INNER JOIN tb_kelas ON tb_nilai.kode_kelas = tb_kelas.kode_kelas
        WHERE
            tb_nilai.nis = tb_siswa.nis
        AND tb_nilai.kode_mapel = tb_matapelajaran.kode_mapel
        AND tb_nilai.kode_kelas = tb_kelas.kode_kelas
        AND tb_nilai.nis = ".$nis."
        AND tb_nilai.kode_kelas LIKE '%".$kode_kelas."%'
        ORDER BY
            tb_nilai.kode_kelas ASC";

        return $this->db->query($query)->result_array();
    }

    #Fungsi ambil tb_materi by kode_mapel & kd_kelas
    public function ambilmateri($kd_mapel, $kd_kelas){
        $this->db->order_by('id', 'ASC');
        return $this->db->get_where('tb_materi',array('kode_mapel'=>$kd_mapel,'kode_kelas'=>$kd_kelas))->result_array();
    }

    public function ambilmateri2($id){
        $this->db->order_by('id', 'ASC');
        return $this->db->get_where('tb_materi',array('id'=>$id))->row_array();
    }

    #Fungsi update login
    public function update_tb_login($username,$newpassword){
        $this->db->where('username',$username);
        return $this->db->update('tb_login',$newpassword);
    }

    #Fungsi ambil tb_login by username
    public function ambil_tb_login($username){
        return $this->db->get_where('tb_login',array('username'=>$username))->row_array();
    }
}