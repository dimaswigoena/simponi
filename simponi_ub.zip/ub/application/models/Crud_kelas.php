<?php 
class Crud_kelas extends CI_Model {
    
    #Fungsi ambil data kelas by kode_kelas
    public function ambil_tb_kelas($kode_kelas){
        return $this->db->get_where('tb_kelas',array('kode_kelas'=>$kode_kelas))->row_array();
    }
    
    #Fungsi ambil semua data kelas
    public function tampil_data_kelas(){
        $this->db->order_by('kode_kelas','asc');
        return $this->db->get('tb_kelas')->result_array();
    }
    
    #Fungsi tambah kelas
    public function add_kelas($data){
        $this->db->insert('tb_kelas',$data);
    }
    
    #Fungsi hapus kelas
    public function delete_kelas($kode_kelas){
        $response = $this->db->delete('tb_kelas',array('kode_kelas'=>$kode_kelas));
        if (!$response) {
          return FALSE;
        }else {
          return TRUE;
        }
    }

    #Fungsi update kelas
    public function update_tb_kelas($kode_kelas,$data_kelas){
        $this->db->where('kode_kelas',$kode_kelas);
        return $this->db->update('tb_kelas',$data_kelas);
    }   
}