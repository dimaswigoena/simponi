<?php
class Crud_mapel extends CI_Model {
    
    #Fungsi ambil data matapelajaran by kode_mapel
    public function ambil_tb_matapelajaran($kode_mapel){
        return $this->db->get_where('tb_matapelajaran',array('kode_mapel'=>$kode_mapel))->row_array();
    }
    
    #Fungsi ambil semua data matapelajaran
    public function tampil_data_mapel(){
        $this->db->order_by('kode_mapel','asc');
        return $this->db->get('tb_matapelajaran')->result_array();
    }
    
    #Fungsi tambah matapelajaran
    public function add_mapel($data){
        $this->db->insert('tb_matapelajaran',$data);
    }

    #Fungsi hapus matapelajaran
    public function delete_mapel($kode_mapel){
        $response = $this->db->delete('tb_matapelajaran',array('kode_mapel'=>$kode_mapel));
        if (!$response) {
          return FALSE;
        }else {
          return TRUE;
        }
    }
    
    #Fungsi update matapelajaran 
    public function update_tb_matapelajaran($kode_mapel,$data_mapel){
        $this->db->where('kode_mapel',$kode_mapel);
        return $this->db->update('tb_matapelajaran',$data_mapel);
    }   
}