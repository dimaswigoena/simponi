<?php
class Crud_guru extends CI_Model {

    /********************************
     * Mengambil Data Dari Database *
     ********************************/

    #Fungsi ambil tb_login by username
    public function ambil_tb_login($username){
        return $this->db->get_where('tb_login',array('username'=>$username))->row_array();
    }

    #Fungsi ambil data guru by kode guru
    public function ambil_tb_guru($kode_guru)
    {
        $query = 
            "SELECT
                tb_guru.kode_guru,
                tb_guru.nama_guru,
                tb_guru.`status`,
                tb_detailguru.jenis_kelamin,
                tb_detailguru.alamat,
                tb_detailguru.tempat_lahir,
                tb_detailguru.tanggal_lahir,
                tb_detailguru.no_tlp,
                tb_detailguru.tmt,
                tb_detailguru.foto,
                tb_matapelajaran.nama_mapel,
                tb_matapelajaran.kode_mapel
            FROM
                tb_guru
            INNER JOIN tb_detailguru ON tb_detailguru.kode_guru = tb_guru.kode_guru
            INNER JOIN tb_matapelajaran ON tb_guru.kode_mapel = tb_matapelajaran.kode_mapel
            WHERE
                tb_guru.kode_guru = tb_detailguru.kode_guru
            AND tb_guru.kode_mapel = tb_matapelajaran.kode_mapel
            AND ".$kode_guru." = tb_guru.kode_guru";

        return $this->db->query($query)->row_array();
    }

    #Fungsi ambil kode,nama,mapel ajar guru 
    public function tampil_data_guru()
    {
        $query = 
            "SELECT
                tb_guru.kode_guru,
                tb_guru.nama_guru,
                tb_matapelajaran.nama_mapel,
                tb_guru.`status`
            FROM
                tb_guru
            INNER JOIN tb_matapelajaran ON tb_guru.kode_mapel = tb_matapelajaran.kode_mapel
            WHERE
                tb_guru.kode_mapel = tb_matapelajaran.kode_mapel
            AND tb_guru.`status` = 1
            ORDER BY
                tb_guru.kode_guru ASC";
        
        return $this->db->query($query)->result_array();
    }

    #Fungsi Cari guru by nama & kode
    public function cari($cari)
    {
        $query = 
            "SELECT
                tb_guru.kode_guru,
                tb_guru.nama_guru,
                tb_matapelajaran.nama_mapel,
                tb_guru.`status`
            FROM
                tb_guru
            INNER JOIN tb_matapelajaran ON tb_guru.kode_mapel = tb_matapelajaran.kode_mapel
            WHERE
                tb_guru.kode_mapel = tb_matapelajaran.kode_mapel
            AND tb_guru.kode_guru LIKE '%".$cari."%'
            OR  tb_guru.nama_guru LIKE '%".$cari."%'
            ORDER BY
                tb_guru.kode_guru ASC";
        
        return $this->db->query($query)->result_array();
    }

    #Fungsi Tambah Guru, Detail Guru, dan Data Login
    public function add_data($table, $data){
        $query = $this->db->insert($table,$data);
        return $query;
    }

    #Fungsi Update tb_guru
    public function update_guru($kode_guru,$dataguru){
        $this->db->where('kode_guru',$kode_guru);
        return $this->db->update('tb_guru',$dataguru);
    }

    #Fungsi Update tb_detailguru
    public function update_detailguru($kode_guru,$detailguru){
        $this->db->where('kode_guru',$kode_guru);
        return $this->db->update('tb_detailguru',$detailguru);
    }

    #Fungsi Update tb_login
    public function update_login($kode_guru,$datalogin){
        $this->db->where('username',$kode_guru);
        return $this->db->update('tb_login',$datalogin);
    }
}
